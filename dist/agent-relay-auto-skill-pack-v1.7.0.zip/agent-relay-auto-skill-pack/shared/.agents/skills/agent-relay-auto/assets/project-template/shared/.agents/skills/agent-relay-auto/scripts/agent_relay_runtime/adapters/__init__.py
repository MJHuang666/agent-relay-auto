"""Agent adapter implementations."""
